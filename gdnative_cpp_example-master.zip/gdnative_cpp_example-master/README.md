GDNative C++ Example
====================

This repository contains the example GDNative C++ library in support of this tutorial:
http://docs.godotengine.org/en/latest/tutorials/plugins/gdnative/gdnative-cpp-example.html

It is now based on the new NativeScript 1.1 Godot-cpp bindings library and will only work with Godot 3.1 and onwards.
Switch to the `3.0` branch to see the original NativeScript 1.0 version.
